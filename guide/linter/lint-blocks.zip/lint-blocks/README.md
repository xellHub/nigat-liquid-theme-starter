# lint-blocks

Flags Shopify sections (and blocks) that are built from hardcoded markup
instead of composed from theme blocks — enforcement for the "sections are
layout, blocks are content" rule your foundational theme is built on.

It parses each `.liquid` file with Shopify's own `@shopify/liquid-html-parser`
(the same parser theme-check uses), not regex, so it understands nesting,
Liquid tags, and loop scope correctly.

## Install

```bash
npm install
```

## Run

```bash
node lint-blocks.js                       # lints sections/ and blocks/ by default
node lint-blocks.js sections               # lint one directory
node lint-blocks.js sections/hero--split.liquid   # lint one file
node lint-blocks.js --json > report.json   # machine-readable output
node lint-blocks.js --tags a,button,span   # customize which tags count as "content"
```

Exit code is `1` if any file has an `error`-severity issue (for CI), `0`
otherwise — `warn` and `info` don't fail the build.

## Rules

| Rule | Severity | Meaning |
|---|---|---|
| `no-blocks-slot` | error | The section has no `{% content_for 'blocks' %}`, no `{% for x in section.blocks %}` loop, and no non-empty `"blocks"` array in its schema. It isn't block-composed at all. |
| `hardcoded-content` | warn | A content tag (`h1`–`h6`, `p`, `blockquote`, `button`, `a`, `figcaption` by default) outside any blocks scope contains literal text with **no** Liquid output anywhere in its subtree. |
| `hardcoded-content-mixed` | info | Same tag, but the subtree also contains *some* Liquid output — partially hardcoded, lower confidence, worth a look. |
| `hardcoded-media` | warn | An `<img src="...">` (or `<source srcset="...">`) outside any blocks scope has a literal path instead of a dynamic/image-picker source. |

Content found *inside* a `{% for block in section.blocks %}` loop body is
never flagged — that's exactly where block-driven content is supposed to
live.

## Suppressing a false positive

Put a comment on the line directly above the node:

```liquid
<!-- lint-disable-next-line hardcoded-content -->
<p>Skip to content</p>
```

or, in pure Liquid:

```liquid
{% comment %} lint-disable-next-line hardcoded-content {% endcomment %}
```

Use this for genuinely structural, non-editorial text — skip links, loading
states, ARIA fallback copy. If you're reaching for it on a section's actual
headline or CTA, that's usually a sign the content belongs in a block
instead.

## Fixtures / examples

`fixtures/sections/` has three worked examples:

- `bad--hardcoded.liquid` — everything hardcoded, no blocks slot at all (4 warnings + 1 error)
- `good--layout.liquid` — pure layout shell using `content_for 'blocks'` (clean)
- `mixed--legacy-loop.liquid` — older `{% for block in section.blocks %}` pattern; content inside the loop is fine, a hardcoded `<h1>` outside it is correctly still flagged
- `suppressed--example.liquid` — same hardcoded pattern, silenced with `lint-disable-next-line`

Run `npm test` to lint them and see the output.

## How `blocks/` is treated differently from `sections/`

`no-blocks-slot` only fires for a file in `blocks/` if that block's own
schema declares a `"blocks"` array (i.e. it's a composite like `card` meant
to nest children) but never actually renders them. A plain atom block
(`button.liquid`, `heading.liquid`) has no blocks of its own by design and
is correctly never flagged for that rule. `hardcoded-content` and
`hardcoded-media` still apply to every file in `blocks/` — an atom is
exactly where those checks matter most, since that's where the actual
literal markup should be replaced by settings, not by nested blocks.

## What it won't catch

This is a heuristic linter, not a full semantic analyzer. It can't tell
whether hardcoded text is a genuine content violation or legitimately
structural — that's what suppression comments are for.
